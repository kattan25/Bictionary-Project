class CreateComments < ActiveRecord::Migration
  def change
    create_table :comments do |t|
      t.text :comm
      t.integer :likes
      t.integer :dislikes
      t.references :user, index: true, foreign_key: true
      t.references :definition, index: true, foreign_key: true

      t.timestamps null: false
    end
  end
end
