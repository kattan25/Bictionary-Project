class WordsController < ApplicationController
	def home
	end
	def index
		@words = Word.all
	end
	
	def destroy
		word = Word.find(params[:id])
		word.destroy
		redirect_to "/glossary"
	end
end
