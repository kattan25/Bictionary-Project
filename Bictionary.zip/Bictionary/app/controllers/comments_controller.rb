class CommentsController < ApplicationController
	def index
		@comments = Comment.all
	end
	def new
	   @definition =  Definition.find(params[:id])
	   @comment = Comment.new
	end

	def create
	   @definition = Definition.find(params[:id])
	   @comment = Comment.new( comm: params[:comm], definition_id: @definition.id, user_id: current_user.id)
	   @comment.save
	   redirect_to show_path(:name => @definition.word.name)
	end
end
