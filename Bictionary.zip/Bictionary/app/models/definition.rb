class Definition < ActiveRecord::Base
  acts_as_votable
  belongs_to :word
  belongs_to :user, dependent: :destroy
  has_many :comments

  accepts_nested_attributes_for :word, :user
end
